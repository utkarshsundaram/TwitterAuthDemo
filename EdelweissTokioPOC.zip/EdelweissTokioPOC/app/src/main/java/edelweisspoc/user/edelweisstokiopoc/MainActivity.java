package edelweisspoc.user.edelweisstokiopoc;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.File;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import edelweisspoc.user.edelweisstokiopoc.application.EdelweissPocApplication;
import edelweisspoc.user.edelweisstokiopoc.mediarecorder.CameraActivity;
import edelweisspoc.user.edelweisstokiopoc.mediarecorder.Main2Activity;
import edelweisspoc.user.edelweisstokiopoc.model.BaseResponseModel;
import edelweisspoc.user.edelweisstokiopoc.network.ApiClientInterface;
import edelweisspoc.user.edelweisstokiopoc.network.INetworkResponse;
import edelweisspoc.user.edelweisstokiopoc.network.MultipartWebServiceCall;
import edelweisspoc.user.edelweisstokiopoc.network.NetworkRequest;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final int MEDIA_RECORDER_REQUEST =1 ;

    private ApiClientInterface mNetworkApi;
    private final String[] requiredPermissions = {
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA,
    };
    private Button buttonNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        if (areCameraPermissionGranted()) {

        } else {
            requestCameraPermissions();
        }
        buttonNext=findViewById(R.id.buttonNext);
        buttonNext.setOnClickListener(this);
        mNetworkApi=EdelweissPocApplication.getClient();
    }

    private void requestCameraPermissions() {
        ActivityCompat.requestPermissions(
                this,
                requiredPermissions,
                MEDIA_RECORDER_REQUEST);
    }
    private boolean areCameraPermissionGranted() {

        for (String permission : requiredPermissions) {
            if (!(ActivityCompat.checkSelfPermission(this, permission) ==
                    PackageManager.PERMISSION_GRANTED)) {
                return false;
            }
        }
        return true;
    }
    @Override
    public void onClick(View view) {
        //sendDataToServer();
        multipart();
    }

    private void multipart(){
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("name", "abc");
            
            

            MultipartEntityBuilder multipartEntityBuilder = MultipartEntityBuilder.create();
            multipartEntityBuilder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
            //String filepath = "/storage/emulated/0/Pictures/CameraSample/VID_20190115_192919.mp4";
            String filepath = "/Internal shared storage/DCIM/Camera/VID_20190115_214447132.mp4";
            if(!filepath.equals("")) {
                try {
                    FileBody fileBody = new FileBody(new File(filepath));
                    multipartEntityBuilder.addPart("video", fileBody);

                    multipartEntityBuilder.addPart("name", new StringBody("abc", ContentType.TEXT_PLAIN));

                    sendDataToServerHttpUrlConnection(multipartEntityBuilder);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }else{
                Toast.makeText(this, "else", Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void sendDataToServerHttpUrlConnection(MultipartEntityBuilder multipartEntityBuilder) {



        MultipartWebServiceCall webServiceCall = new MultipartWebServiceCall(this, new INetworkResponse() {
            @Override
            public void onSuccess(String response) {
                Toast.makeText(getApplicationContext(),response+"sucess", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(String error) {
                Toast.makeText(getApplicationContext(), error, Toast.LENGTH_SHORT).show();
            }
        });
        webServiceCall.execute(multipartEntityBuilder, "http://192.168.14.234:8000/api/userinfos");

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {

        if (MEDIA_RECORDER_REQUEST != requestCode) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            return;
        }

        boolean areAllPermissionsGranted = true;
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) {
                areAllPermissionsGranted = false;
                break;
            }
        }

        if (areAllPermissionsGranted) {

        } else {
            // User denied one or more of the permissions, without these we cannot record
            // Show a toast to inform the user.
            Toast.makeText(getApplicationContext(),
                    "App need the camera permission",
                    Toast.LENGTH_SHORT)
                    .show();
        }
    }
    public void sendDataToServer() {
        MultipartBody.Part body = prepareFilePart("video");

// create a map of data to pass alon

        HashMap<String, String> map = new HashMap<>();
        map.put("name", "kamal");
        map.put("dob", "06-07-1986");
        map.put("marital_status", "Married");
        map.put("email","kamal.arora@kelltontech.com");

      // finally, execute the request
        Call<BaseResponseModel> call = mNetworkApi.uploadFileWithPartMap(map, body);
        new NetworkRequest<BaseResponseModel>(this, call, 1);
    }

    @NonNull
    private MultipartBody.Part prepareFilePart(String partName) {
        // https://github.com/iPaulPro/aFileChooser/blob/master/aFileChooser/src/com/ipaulpro/afilechooser/utils/FileUtils.java
        // use the FileUtils to get the actual file by uri
        File file = new File("/storage/emulated/0/Pictures/CameraSample/VID_20190115_192919.mp4");
        Uri uri=Uri.fromFile(file);
        // create RequestBody instance from file
        RequestBody requestFile =
                RequestBody.create(
                        MediaType.parse("/storage/emulated/0/Pictures/CameraSample/VID_20190115_192919.mp4"),
                        file
                );

        // MultipartBody.Part is used to send also the actual file name
        return MultipartBody.Part.createFormData(partName, file.getName(), requestFile);
    }
}
