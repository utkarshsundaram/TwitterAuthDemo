package edelweisspoc.user.edelweisstokiopoc.network;

public interface INetworkResponse {
    public void onSuccess(String response);
    public void onError(String error);
}
