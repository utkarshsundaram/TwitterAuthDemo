package edelweisspoc.user.edelweisstokiopoc.model;

import java.io.Serializable;

public class BaseResponseModel implements Serializable {

    public int status;  //Success //Failed
}
