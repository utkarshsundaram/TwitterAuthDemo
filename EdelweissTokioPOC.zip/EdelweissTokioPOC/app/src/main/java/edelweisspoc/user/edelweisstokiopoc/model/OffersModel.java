package edelweisspoc.user.edelweisstokiopoc.model;

public class OffersModel {
    public String mOffersHeading;
    public String mOffersPrice;
    public String mOffersDetail;
}
