package edelweisspoc.user.edelweisstokiopoc.model;

public class DatabaseModel {
    public String mMobileNo;
    public String mLocation;
    public String mFileUrl;
}
