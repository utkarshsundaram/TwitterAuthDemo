package edelweisspoc.user.edelweisstokiopoc.model;

import java.io.Serializable;
import java.util.ArrayList;

public class EmailModel implements Serializable {
    public String mobile;
    public String CAREDOSE;
    public ArrayList<String> file;
    public String location;
    public String transactionId;
}
